import { Component } from '@angular/core';
import { NgClass } from '@angular/common';
import { ThemeService } from '../core/services/theme.service';
import { FormsModule, NgForm } from '@angular/forms';

export interface Employee {
  EmpId: string;
  FName: string;
  Dept: string;
  MailId: string;
  DOB: string; // Format: 'YYYY-MM-DD'
}


const employees:Array<Employee> = [
  {
    EmpId: 'EMP001',
    FName: 'Alice',
    Dept: 'HR',
    MailId: 'alice@example.com',
    DOB: '1990-04-15'
  },
  {
    EmpId: 'EMP002',
    FName: 'Bob',
    Dept: 'Finance',
    MailId: 'bob@example.com',
    DOB: '1988-12-05'
  },
  {
    EmpId: 'EMP003',
    FName: 'Charlie',
    Dept: 'Engineering',
    MailId: 'charlie@example.com',
    DOB: '1995-07-23'
  },
  {
    EmpId: 'EMP004',
    FName: 'Diana',
    Dept: 'Marketing',
    MailId: 'diana@example.com',
    DOB: '1992-09-11'
  },
  {
    EmpId: 'EMP005',
    FName: 'Ethan',
    Dept: 'Sales',
    MailId: 'ethan@example.com',
    DOB: '1993-02-28'
  },
  {
    EmpId: 'EMP006',
    FName: 'Fiona',
    Dept: 'IT',
    MailId: 'fiona@example.com',
    DOB: '1991-06-19'
  },
  {
    EmpId: 'EMP007',
    FName: 'George',
    Dept: 'Operations',
    MailId: 'george@example.com',
    DOB: '1989-11-30'
  },
  {
    EmpId: 'EMP008',
    FName: 'Hannah',
    Dept: 'Legal',
    MailId: 'hannah@example.com',
    DOB: '1994-08-14'
  },
  {
    EmpId: 'EMP009',
    FName: 'Ian',
    Dept: 'Support',
    MailId: 'ian@example.com',
    DOB: '1987-03-07'
  },
  {
    EmpId: 'EMP010',
    FName: 'Jane',
    Dept: 'Finance',
    MailId: 'jane@example.com',
    DOB: '1990-10-21'
  },
  {
    EmpId: 'EMP011',
    FName: 'Kyle',
    Dept: 'Engineering',
    MailId: 'kyle@example.com',
    DOB: '1996-05-09'
  },
  {
    EmpId: 'EMP012',
    FName: 'Laura',
    Dept: 'HR',
    MailId: 'laura@example.com',
    DOB: '1993-01-17'
  },
  {
    EmpId: 'EMP013',
    FName: 'Mike',
    Dept: 'Sales',
    MailId: 'mike@example.com',
    DOB: '1986-09-25'
  },
  {
    EmpId: 'EMP014',
    FName: 'Nina',
    Dept: 'IT',
    MailId: 'nina@example.com',
    DOB: '1997-12-03'
  },
  {
    EmpId: 'EMP015',
    FName: 'Oscar',
    Dept: 'Support',
    MailId: 'oscar@example.com',
    DOB: '1992-07-01'
  }
];


@Component({
  selector: 'app-employee',
  imports: [NgClass,FormsModule],
  templateUrl: './employee.component.html',
  styleUrl: './employee.component.css'
})
export class EmployeeComponent {
  selectedEmployeeIds: Set<string> = new Set();
  toggleEmployeeSelection(empId: string) {
    if (this.selectedEmployeeIds.has(empId)) {
      this.selectedEmployeeIds.delete(empId);
    } else {
      this.selectedEmployeeIds.add(empId);
    }
  }

  selectedEmployees: any[] = [];
isEditModalOpen = false;

openEditModal() {
  this.selectedEmployees = this.data
    .filter(emp => this.selectedEmployeeIds.has(emp.EmpId))
    .map(emp => ({ ...emp })); // Deep clone
  this.isEditModalOpen = true;
}

deleteSelectedEmployees() {
  this.data = this.data.filter(emp => !this.selectedEmployeeIds.has(emp.EmpId));
  this.selectedEmployeeIds.clear(); // Clear the selection
}

submitAllEdits() {
  this.selectedEmployees.forEach(edited => {
    const index = this.data.findIndex(emp => emp.EmpId === edited.EmpId);
    if (index !== -1) {
      this.data[index] = { ...edited }; // Update main list
    }
  });
  this.closeEditModal();
}

closeEditModal() {
  this.isEditModalOpen = false;
}
  


  selectAllEmployees() {
    const allSelected = this.selectedEmployeeIds.size === this.data.length;

    
  
    if (allSelected) {
      // Deselect all by clearing the set
      this.selectedEmployeeIds.clear();
    } else {
      // Select all using the existing toggle method logic
      this.data.forEach(emp => {
        if (!this.selectedEmployeeIds.has(emp.EmpId)) {
          this.toggleEmployeeSelection(emp.EmpId);
        }
      });
    }
  }
  

  isModalOpen = false;

  isAllSelected(): boolean {
    return this.selectedEmployeeIds.size === this.data.length;
  }
  

  openModal() {
    console.log("Hello");
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
  }

  addEmployee(form: any) {
    console.log('Form submitted:', form.value);
    this.data.push(form.value);
    this.closeModal();
  }

   data:Array<Employee>=employees;
   theme=''; 

   constructor(public themeService: ThemeService) {}

   formData = {
    EmpId: '',
    FName: '',
    Dept: '',
    MailId: '',
    DOB: ''
  };
  

  


   sortColumn = '';
   sortDirection: 'asc' | 'desc' = 'asc';
   
   sortBy(column: string) {
     if (this.sortColumn === column) {
       this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
     } else {
       this.sortColumn = column;
       this.sortDirection = 'asc';
     }
   
     this.data.sort((a:any, b:any) => {
       const valA = a[column];
       const valB = b[column];
   
       if (valA < valB) return this.sortDirection === 'asc' ? -1 : 1;
       if (valA > valB) return this.sortDirection === 'asc' ? 1 : -1;
       return 0;
     });
   }
   
   
  toggleTheme() {
    this.themeService.toggleTheme();
  }

}
