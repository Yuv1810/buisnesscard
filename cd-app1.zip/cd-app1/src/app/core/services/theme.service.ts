import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  currentTheme: 'light' | 'dark' = 'light';

  constructor() {
    const storedTheme = localStorage.getItem('theme');
    if (storedTheme === 'dark') {
      this.currentTheme = 'dark';
      document.body.classList.add('dark-theme');
    } else {
      this.currentTheme = 'light';
      document.body.classList.remove('dark-theme');
      document.body.classList.add('light-theme');

    }
  }

  get getTheme(){
    return this.currentTheme;
  }

  toggleTheme() {
    this.currentTheme = this.currentTheme === 'light' ? 'dark' : 'light';

    if (this.currentTheme === 'dark') {
      document.body.classList.add('dark-theme');
    } else {
      document.body.classList.remove('dark-theme');
    }

    localStorage.setItem('theme', this.currentTheme);
  }
}
