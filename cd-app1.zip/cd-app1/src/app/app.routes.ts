// src/app/app.routes.ts
import { Routes } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';

export const routes: Routes = [
  { path: 'employee', component: EmployeeComponent },
  { path: '', redirectTo: '', pathMatch: 'full' }
];
